/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorphinventory;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Aira Joie Piopongco
 */


public class InventoryData {
    String dateEntered;
    String stockLabel;
    String stockBrand;
    String stockEngineNumber;
    String status;

    //Constructor for current items based on MotorPH inventory
    public InventoryData(String dateEntered, String stockLabel, String stockBrand, String stockEngineNumber, String status) {
        this.dateEntered = dateEntered;
        this.stockLabel = stockLabel;
        this.stockBrand = stockBrand;
        this.stockEngineNumber = stockEngineNumber;
        this.status = status;
    }

    // Constructor for products to be added
    public InventoryData(String stockBrand, String stockEngineNumber) {
        this.dateEntered = new SimpleDateFormat("yyyy-MM-dd").format(new Date()); 
        this.stockLabel = "New"; 
        this.stockBrand = stockBrand;
        this.stockEngineNumber = stockEngineNumber;
        this.status = "On-hand"; 
    }


    public String getDateEntered() {
        return dateEntered;
    }

    public String getStockLabel() {
        return stockLabel;
    }

    public String getStockBrand() {
        return stockBrand;
    }

    public String getStockEngineNumber() {
        return stockEngineNumber;
    }

    public String getStatus() {
        return status;
    }

  @Override
    public String toString() {
        return dateEntered + ", " + stockLabel + ", " + stockBrand + ", " + stockEngineNumber + ", " + status;
    }
}