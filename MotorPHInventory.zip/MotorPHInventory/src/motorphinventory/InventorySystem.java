/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorphinventory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author Aira Joie Piopongco
 */

public class InventorySystem {

    private ArrayList<InventoryData> inventory;

    public InventorySystem() {
        inventory = new ArrayList<>();
        currentInventory(); 
    }

    private void currentInventory() {
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "142QVTSIUR", "On-hand"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "PZCT1S00XE", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "4VBTV8YNM7", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "95AN3AWVF4", "On-hand"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kawasaki", "483QHIM661", "On-hand"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kymco", "SPHA17SSEE", "On-hand"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kymco", "0AV7SWGX93", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kymco", "QMUB6UYLKL", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "V96GMTFFEI", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kawasaki", "4J8UA0FMVY", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kawasaki", "A8BDL926FA", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Kawasaki", "X8G5ZZ7A69", "Sold"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "TY5SU0WPDX", "On-hand"));
        inventory.add(new InventoryData("2023-01-02", "Old", "Honda", "5Q0EZG7WKB", "On-hand"));
        inventory.add(new InventoryData("2023-06-02", "Old", "Suzuki", "9XUOUOJ2XZ", "On-hand"));
        inventory.add(new InventoryData("2023-06-02", "Old", "Kymco", "YUL4UTC4FU", "On-hand"));
        inventory.add(new InventoryData("2023-06-02", "Old", "Kymco", "2ESQRHAXWG", "On-hand"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Kymco", "J8JA99VWZE", "Sold"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Kymco", "NS530HOT9H", "Sold"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Suzuki", "URIA0XXM05", "Sold"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Yamaha", "IDN93SI4KW", "Sold"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Honda", "PVAWKD51CE", "Sold"));
        inventory.add(new InventoryData("2023-07-02", "Old", "Honda", "K4KHCQAU41", "Sold"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Honda", "Z4NY5JGZZT", "Sold"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Honda", "IRQACSKUNZ", "Sold"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Yamaha", "TMZCTALNDL", "Sold"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Yamaha", "DVFUIA0YVB", "Sold"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Kymco", "4M793VVAHI", "On-hand"));
        inventory.add(new InventoryData("2023-08-02", "Old", "Suzuki", "5N7IQVJ2BA", "On-hand"));
        inventory.add(new InventoryData("2023-01-03", "New", "Suzuki", "NO8VW05PU9", "On-hand"));
        inventory.add(new InventoryData("2023-01-03", "New", "Yamaha", "NWIP2MQEIN", "Sold"));
        inventory.add(new InventoryData("2023-01-03", "New", "Kawasaki", "1HCWCVZSX8", "Sold"));
        inventory.add(new InventoryData("2023-03-03", "New", "Kawasaki", "Z46VKPIJBY", "Sold"));
        inventory.add(new InventoryData("2023-03-03", "New", "Kawasaki", "LYQVEHJ6IU", "Sold"));
        inventory.add(new InventoryData("2023-03-03", "New", "Yamaha", "BVGQQNMATL", "Sold"));
        inventory.add(new InventoryData("2023-04-03", "New", "Kymco", "URWMSQZCBU", "Sold"));
        inventory.add(new InventoryData("2023-04-03", "New", "Yamaha", "5NGI5UZ8T2", "On-hand"));
        inventory.add(new InventoryData("2023-05-03", "New", "Honda", "W2UYM0EIRS", "On-hand"));
        inventory.add(new InventoryData("2023-05-03", "New", "Honda", "AITLTSJUK2", "On-hand"));
        inventory.add(new InventoryData("2023-05-03", "New", "Yamaha", "45CNYV7IFF", "On-hand"));
        inventory.add(new InventoryData("2023-06-03", "New", "Kymco", "MXS36NKV96", "Sold"));
        inventory.add(new InventoryData("2023-06-03", "New", "Kymco", "PWM3MJWPYE", "Sold"));
        inventory.add(new InventoryData("2023-06-03", "New", "Kymco", "5I80N9HB7W", "Sold"));
        inventory.add(new InventoryData("2023-06-03", "New", "Yamaha", "D01JMJL9PG", "On-hand"));
        inventory.add(new InventoryData("2023-06-03", "New", "Suzuki", "1R88 BOJW8W", "On-hand"));
        inventory.add(new InventoryData("2023-07-03", "New", "Suzuki", "LAMH9Y1YD6", "On-hand"));
        inventory.add(new InventoryData("2023-07-03", "New", "Yamaha", "02G7NJCRGS", "On-hand"));
        inventory.add(new InventoryData("2023-07-03", "New", "Kawasaki", "392XSUBMUW", "On-hand"));

    }

    //to add products to the inventory list 
    //unable to save changes or add new product in the inventory after exiting the program tho
    public void addProduct(InventoryData product) {
        for (InventoryData existingProduct : inventory) {
            if (existingProduct.getStockEngineNumber().equals(product.getStockEngineNumber())) {
                System.out.println("Product with engine number " + product.getStockEngineNumber() + " already exists in the inventory.");
                return; 
            }
        }
        inventory.add(product);
        System.out.println("Stock: " + product + " has been successfully added to the inventory.");
    }

    /*for deleting product from the inventory using engine number with the condition that if product
    is on-hand it will prompt user to continue action or not*/
    public void deleteProduct(String stockEngineNumber) {
        for (InventoryData product : inventory) {
            if (product.getStockEngineNumber().equals(stockEngineNumber)) {
                if ("Sold".equalsIgnoreCase(product.getStatus())) {
                    inventory.remove(product);
                    System.out.println("Stock with Engine Number " + stockEngineNumber + " has been deleted from the inventory.");
                } else if ("On-hand".equalsIgnoreCase(product.getStatus())) {
                    System.out.print("The product is currently on-hand. Are you sure you want to delete it? (Yes/No): ");
                    Scanner scanner = new Scanner(System.in);
                    String confirmation = scanner.nextLine().trim();
                    if ("Yes".equalsIgnoreCase(confirmation)) {
                        inventory.remove(product);
                        System.out.println("Stock with Engine Number " + stockEngineNumber + " has been deleted from the inventory.");
                    } else  {
                        System.out.println("Deletion cancelled.");
                    }
                }
                return; 
            }
        }
        System.out.println("Product with Engine Number: " + stockEngineNumber + " is not found in the inventory.");
    }
    
    //display all current products in the inventory
    public void displayProducts() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is currently empty.");
        } else {
            System.out.println("Inventory: ");
            for (InventoryData item : inventory) {
                System.out.println(item);
            }
        }
    }
    
    // sort products prompt option to sort through date entered or brand
    public void sortProducts(String sortBy) {
        if ("Date Entered".equalsIgnoreCase(sortBy)) {
            Collections.sort(inventory, Comparator.comparing(InventoryData::getDateEntered));
            System.out.println("Products successfully sorted by Date Entered.");
        } else if ("Brand".equalsIgnoreCase(sortBy)) {
            Collections.sort(inventory, Comparator.comparing(InventoryData::getStockBrand));
            System.out.println("Products successfully sorted by Brand.");
        } else {
            System.out.println("Invalid input. Please choose sort order by 'Date Entered' or 'Brand'.");
        }
    }
    
    // sorting product using engine number
    public void searchProduct(String stockEngineNumber) {
        for (InventoryData product : inventory) {
            if (product.getStockEngineNumber().equals(stockEngineNumber)) {
                System.out.println("Stock found: " + product);
                return;
            }
        }
        System.out.println("Item with Engine Number:" + stockEngineNumber + " is not found.");
    }

    public static void main(String[] args) {
        InventorySystem inventory = new InventorySystem();
        Scanner scanner = new Scanner(System.in);
        String command;
       
        do {
        System.out.println("---------------------------------------------------");
        System.out.println("--------MotorPH Inventory Management System--------");
        System.out.println("---------------------------------------------------");
        System.out.println("1. Display Inventory");
        System.out.println("2. Add Stock to Inventory");
        System.out.println("3. Delete Stock from Inventory");
        System.out.println("4. Sort Inventory");
        System.out.println("5. Search Inventory");
        System.out.println("6. Exit");
        System.out.println("---------------------------------------------------");
        command = scanner.nextLine();

        switch (command) {
            case "1" -> {
                inventory.displayProducts();
                promptReturnToMenu(scanner);
            }
            
            case "2" -> {
                System.out.print("Enter Brand: ");
                String brand = scanner.nextLine().trim();
                String engineNumber = "";
                while (true) {
                    System.out.print("Enter Engine Number (10 characters): ");
                    engineNumber = scanner.nextLine().trim();
                    if (engineNumber.length() == 10) {
                        break;
                    } else {
                        System.out.println("Invalid input. Please try again.");
                    }
                }
                   if (!brand.isEmpty()) {
                    inventory.addProduct(new InventoryData(brand, engineNumber));
                    } else {
                    System.out.println("Invalid input. Field cannot be empty.");
                    promptReturnToMenu(scanner);
                }
            }
            
            case "3" -> {
                System.out.print("Enter Engine Number to delete: ");
                String engineNumberToDelete = scanner.nextLine().trim();
                if (engineNumberToDelete.length() != 10) {
                    System.out.println("Invalid Engine Number.");
                } else {
                    inventory.deleteProduct(engineNumberToDelete);
                }
                promptReturnToMenu(scanner);
            }
           

            case "4" -> {
                System.out.println("How would you like to sort the inventory?");
                System.out.println("1 - Sort by Date Entered");
                System.out.println("2 - Sort by Brand");
                System.out.print("Select (1 or 2): ");
                String sortChoice = scanner.nextLine().trim();

                String sortBy;
                if ("1".equals(sortChoice)) {
                    sortBy = "Date Entered";
                } else if ("2".equals(sortChoice)) {
                    sortBy = "Brand";
                } else {
                    System.out.println("Invalid input. Please select either 1 or 2.");
                    promptReturnToMenu(scanner);
                    continue; 
                }

                inventory.sortProducts(sortBy);
                inventory.displayProducts();
                promptReturnToMenu(scanner);
            }

            case "5" -> {
                System.out.print("Enter Brand to search: ");
                String brandToSearch = scanner.nextLine().trim();
                inventory.searchProduct(brandToSearch);
                inventory.displayProducts();
                promptReturnToMenu(scanner);
            }

           case "6" -> {
                System.out.println("Successfully exited the inventory system.");
                scanner.close();
                return;
            }

            default -> System.out.println("Invalid command. Please try again.");
        }
        
    } while (!command.equals("6"));
}
        private static void promptReturnToMenu(Scanner scanner) {
        System.out.println("");
        System.out.print("----------");
        System.out.print("Press Enter to Access Main Menu");
        System.out.print("----------");
        System.out.println("");
        scanner.nextLine();
    }
}